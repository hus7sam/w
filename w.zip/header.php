<?php


?>

<div class="bar">
    <h2>| فينا خير  </h2>
    <a href="index.php">الرئيسية </a>
    <a href="display.php"> العرض</a>
    <img class="img_logo" src="img/logo.png">

</div>