<?php

?>

<?php  include ("header.php")?>

<style>

    <?php  include ("css/style.css")?>
</style>

<div class="Donation_Gr_container">


    <div class="Donation_g_item">
        <img src="img/alb.jpg">

        0123456789456
    </div>

    <div class="Donation_g_item">

        <img src="img/22.png">
        0123456789456
    </div>

    <div class="Donation_g_item">
        <img src="img/NCB.png">


        0123456789456
    </div>

    <div class="Donation_g_item">
        <img src="img/aljaxira.jpg">

        0123456789456
    </div>

    <div class="Donation_g_item">
        <img src="img/ww.jpg">

        0123456789456
    </div>

    <div class="Donation_g_item">
        <img src="img/هinvestmen.jpg">

        0123456789456
    </div>

    <div class="Donation_g_item">
        <img src="img/arr.png">

        0123456789456
    </div>

    <div class="Donation_g_item">
        <img src="img/francy.jpg">

        0123456789456
    </div>

    <div class="Donation_g_item">
        <img src="img/aa.png">

        0123456789456
    </div>

    <div class="Donation_g_item">
        <img src="img/ddd.png">

        0123456789456
    </div>

    <div class="Donation_g_item">
        <img src="img/xxxx.jpg">

        0123456789456
    </div>

    <div class="Donation_g_item">
        <img src="img/rrr.jpg">

        0123456789456
    </div>

    <div class="Donation_g_item">
        <img src="img/qqq.jpg">

        0123456789456

        SA0123456789456
    </div>

    <div class="Donation_g_item">
        <img src="img/zzz.jpg">

        0123456789456
    </div>

    <div class="Donation_g_item">
        <img src="img/p4.png">

        <a href="https://paypal.me/alsaedi808?locale.x=en_US"> تبرع عبر paypal</a>
    </div>

</div>
<?php include ("footer.php");?>