<?php


?>


<div class="footer">

    <div class="fo_Gr-container">


        <div class="fo_g-item">
            <h1> الادارة&nbsp; <sub>لدعاية والاعلان</sub> </h1>

            <a href="mailto:alsaedi@finakhayr.com">alsaedi@finakhayr.com</a>
        </div>

        <div class="fo_g-item">
            <h1> الشكاوى و الإقتراحات </h1>

            <a href="https://api.whatsapp.com/send?phone=+966530423063">0530423063 - واتس اب</a><br>
        </div>

        <div class="fo_g-item">
            <h1> التوظيف</h1>
            <a href="mailto:jobs@finakhayr.com">jobs@finakhayr.com</a>
        </div>


        <div class="fo_g-item">
            <h1>هل ترغب بتقديم دعم مادي للموقع؟ </h1>
            <a href="donation.php">يمكنك التبرع من هنا </a><br>
        </div>

        <div class="fo_g-item">
            <h1> تطوير الموقع </h1>
            <p>م/ حسام  الصاعدي</p>
            <a href="https://api.whatsapp.com/send?phone=+966530423063">0530423063</a><br>
            <a href="mailto:h.alsaedi1992@outlook.com">h.alsaedi1992@outlook.com</a><br>
        </div>

    </div>

</div>
<div class="alert_copy"> جميع الحقوق محفوظة <?php echo  date("Y");?> </div>